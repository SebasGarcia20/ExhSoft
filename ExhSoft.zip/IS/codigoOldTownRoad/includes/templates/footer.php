    <!--footer-->
    <footer class="site-footer pt-5 bg-dark">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-3 col-md-4">
                    <h4 class="mb-3">Old<strong>Town</strong>Road</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                </div>
                <div class="col-12 mb-3 col-md-4">
                    <h4 class="mb-3">Contáctanos</h4>
                    <ul class="row px-0">
                        <li class="col-12">
                            <i class="fas fa-map-marker-alt col-1 text-center"></i>
                            <span class="col-11">Dirección: Cra 45 No. 18 - 42</span>
                        </li>
                        <li class="col-12">
                            <i class="fas fa-envelope col-1 text-center"></i>
                            <span class="col-11">Email: oldtownroad@booking.com</span>
                        </li>
                        <li class="col-12">
                            <i class="fas fa-tty col-1 text-center"></i>
                            <span class="col-11">Telefono: 6 97 8530</span>
                        </li>
                        <li class="col-12">
                            <i class="fas fa-mobile-alt col-1 text-center"></i>
                            <span class="col-11">Célular: 320 843 0206</span>
                        </li>
                    </ul>
                </div>
                <div class="col-12 mb-3 col-md-4">
                        <h4 class="mb-3">Redes sociales</h4>
                    <nav class="redes-sociales">
                        <a href="https://www.facebook.com/" target="_blank" class="btn btn-dark"><i class="fab fa-facebook-square"></i></a>
                        <a href="https://twitter.com/" class="btn btn-dark" target="_blank"><i class="fab fa-twitter"></i></a>
                        <a href="https://co.pinterest.com/" class="btn btn-dark" target="_blank"><i class="fab fa-pinterest-square"></i></i></a>
                        <a href="https://www.youtube.com/" class="btn btn-dark" target="_blank"><i class="fab fa-youtube-square"></i></a>
                        <a href="https://www.instagram.com/" class="btn btn-dark" target="_blank"><i class="fab fa-instagram"></i></a>
                    </nav>
                </div>
                <div class="col-12 border-top pt-1">
                    <p class="text-center">
                        Todos los derechos Reservados <a href="index.php" class="text-white">OLDTOWNROAD</a> 2019.
                    </p>
                </div>
            </div>
        </div>
    </footer>

    <!-- scripts -->
    <script src="codigoOldTownRoad/jQuery/jquery-3.4.1.min.js"></script>
    <script src="codigoOldTownRoad/js/popper.min.js"></script>
    <script src="codigoOldTownRoad/js/bootstrap.min.js"></script>
    <script src="codigoOldTownRoad/js/validarFormularios.js"></script>
    <script src="codigoOldTownRoad/jQuery/main.js"></script>

    <!-- cookies -->
    <script src="codigoOldTownRoad/js/cookies/contar_visitas.js"></script>
</body>
</html>