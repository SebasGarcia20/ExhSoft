        <!-- Footer -->
        <footer class="sticky-footer bg-white">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>Copyright &copy; ExhSoft</span>
            </div>
          </div>
        </footer>
        <!-- Fin Footer -->
      </div>
      <!--Fin Contenido Wrapper -->
    </div>
    <!-- Fin Pagina Wrapper -->

    <!-- Boton desplazarse hacia arriba -->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Modal Salir -->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
      aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Listo para salir?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Selecciona "Salir" abajo si esta listo para terminar tu sesión actual.</div>
          <div class="modal-footer">
            <button class="btn btn-primary" type="button" data-dismiss="modal">Cancelar</button>
            <a class="btn btn-secondary" href="../login.php">Salir</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- scripts -->
  <script src="../codigoOldTownRoad/jQuery/jquery-3.4.1.min.js"></script>
  <script src="../codigoOldTownRoad/js/popper.min.js"></script>
  <script src="../codigoOldTownRoad/js/bootstrap.min.js"></script>
  <script src="../codigoOldTownRoad/js/jquery.easing.min.js"></script>
  <script src="../codigoOldTownRoad/jQuery/jquery.dataTables.min.js"></script>
  <script src="../codigoOldTownRoad/jQuery/dataTables.bootstrap4.min.js"></script>
  <script src="../codigoOldTownRoad/jQuery/datatables-demo.js"></script>
  <script src="../codigoOldTownRoad/js/validarFormularios.js"></script>
  <script src="../codigoOldTownRoad/jQuery/admin.min.js"></script>
  <!-- map -->
  <script src='https://api.mapbox.com/mapbox-gl-js/v1.0.0/mapbox-gl.js'></script>
  <script src="../codigoOldTownRoad/js/mapAdmin.js"></script>
</body>
</html>