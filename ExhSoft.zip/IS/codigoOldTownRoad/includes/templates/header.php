<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,400i,700,700i&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="codigoOldTownRoad/css/bootstrap.min.css">
    <link rel="stylesheet" href="codigoOldTownRoad/css/all.min.css">
    <link rel="stylesheet" href="https://api.mapbox.com/mapbox-gl-js/v1.0.0/mapbox-gl.css"/>
    <link rel="stylesheet" href="codigoOldTownRoad/css/main.css">

    <title>Old Town Road</title>
</head>
<body>
    <!--header-->
    <header class="site-header">
        <nav class="navbar navbar-expand-lg navbar-dark navbar-shrink bg-dark fixed-top px-lg-4 mb-5" id="mainNav">
            <a class="navbar-brand" href="index.php">
                <i class="fas fa-hands-helping"></i>
                <strong>Exhsoft</strong>
            </a>
            <div class="collapse navbar-collapse d-lg-inline scrollNav" id="collapsibleNavId">
                <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                    <hr class="d-lg-none">
                </ul>
                <ul class="nav navbar-nav">
                    <li class="nav-item btn btn-warning p-0">
                        <a class="nav-link font-weight-bold" href="admin/admin.php">Administrar</a>
                    </li>
                    <div class="topbar-divider d-none d-md-block"></div>
                    <li class="nav-item">
                        <a class="nav-link" href="registrarse.php">Registrarse</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">Iniciar sesión</a>
                    </li>
                </ul>
            </div>
        </nav>