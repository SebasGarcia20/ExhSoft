<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!--<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">-->
  <link
    href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
    rel="stylesheet">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="../codigoOldTownRoad/css/all.min.css">
  <link rel="stylesheet" href="https://api.mapbox.com/mapbox-gl-js/v1.0.0/mapbox-gl.css" />
  <link rel="stylesheet" href="../codigoOldTownRoad/css/admin.min.css">
  <link rel="stylesheet" href="../codigoOldTownRoad/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../codigoOldTownRoad/css/bootstrap.min.css">

  <title>Exhsoft</title>
</head>

<body id="page-top">
  <!-- Page Wrapper -->
  <div id="wrapper">
    <!-- Sidebar -->
    <ul class="navbar-nav bg-dark sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - titulo -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="../index.php">
        <div class="sidebar-brand-icon">
        <i class="fas fa-hands-helping"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Exhsoft</div>
      </a>
      <hr class="sidebar-divider my-0">

      <!-- item tablero -->
      <li class="nav-item">
        <a class="nav-link" href="admin.php">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Tablero</span></a>
      </li>
      <hr class="sidebar-divider">
      <!-- Heading -->
      <div class="sidebar-heading">
        Interfaz
      </div>

      <!-- Usuarios - opciones -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseUser" aria-expanded="true"
          aria-controls="collapseUser">
          <i class="fas fa-user"></i>
          <span>Usuarios</span>
        </a>
        <div id="collapseUser" class="collapse" aria-labelledby="headingUser" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Opciones:</h6>
            <a class="collapse-item" href="listarUsuarios.php">Gestionar usuarios</a>
            <a class="collapse-item" href="crearUsuario.php">Añadir nuevo usuario</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTarea" aria-expanded="true"
          aria-controls="collapseUser">
          <i class="fas fa-user"></i>
          <span>Registro de demandas</span>
        </a>
        <div id="collapseTarea" class="collapse" aria-labelledby="headingUser" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Opciones:</h6>
            <a class="collapse-item" href="listarTareas.php">Gestionar registro de <br> demandas</a>
          </div>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseOfertaTarea" aria-expanded="true"
          aria-controls="collapseUser">
          <i class="fas fa-user"></i>
          <span>Asignación de demandas</span>
        </a>
        <div id="collapseOfertaTarea" class="collapse" aria-labelledby="headingUser" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Opciones:</h6>
            <a class="collapse-item" href="listarOfertaTarea.php">Gestionar demandas <br> asignadas</a>
          </div>
        </div>
      </li>
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- Fin Sidebar -->