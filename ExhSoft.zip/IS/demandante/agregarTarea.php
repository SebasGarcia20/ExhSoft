<?php

include("conection_database.php");

if(isset($_POST['agregarTarea'])){
    $nombreTarea = $_POST['nombreTarea'];
    $descripcion = $_POST['descripcion'];
    $codigo = $_SESSION['iddemandante'];

    $query = "INSERT INTO tareas(nombreTarea,iddemandante,descripcion) values ('$nombreTarea','$codigo','$descripcion')";
    echo $query;
    $resultado = mysqli_query($con, $query);
    if(!$resultado){
        die("Query Failed");
    }
    
    $_SESSION['mensaje'] ='¡La Tarea ha sido agregado de manera exitosa!';
    $_SESSION['tipoMensaje'] ='success';

    header("Location: crearTarea.php");
}


?>