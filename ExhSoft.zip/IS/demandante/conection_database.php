<?php
session_start();
$con = mysqli_connect('localhost','root','','extracurricular') or die ("Erro al conectar a la base de datos");

?>