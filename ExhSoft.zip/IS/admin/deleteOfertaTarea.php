<?php

include("conection_database.php");

if(isset($_GET['codigo'])){
    $codigo= $_GET['codigo'];
    $query= "DELETE FROM ofertante_tarea WHERE idOfertaTarea = $codigo";
    $result = mysqli_query($con, $query);
    if (!result){
        die("Query Failed");
    }

    $_SESSION['mensaje'] = '¡Asignación de demanda removida de manera exitosa';
    $_SESSION['tipoMensaje'] = 'succes';
    header("Location: listarOfertaTarea.php");
}

?>