<?php

include("conection_database.php");

if(isset($_POST['agregarUsuario'])){
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena'];
    $tipoUsuario = $_POST['tipoUsuario'];

    $query = "INSERT INTO usuario(usuario,contrasena,tipoUsuario) values ('$usuario','$contrasena','$tipoUsuario')";
    echo $query;
    $resultado = mysqli_query($con, $query);
    if(!$resultado){
        die("Query Failed");
    }
    
    $_SESSION['mensaje'] ='¡El usuario ha sido agregado de manera exitosa!';
    $_SESSION['tipoMensaje'] ='success';

    header("Location: crearUsuario.php");
}


?>