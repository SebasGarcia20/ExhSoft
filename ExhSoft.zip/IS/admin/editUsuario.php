<?php
    include("conection_database.php");

    if(isset($_POST['update'])){
        $codigo = $_GET['codigo'];
        $usuario = $_POST['usuario'];
        $contrasena = $_POST['contrasena'];
        $tipoUsuario = $_POST['tipoUsuario'];

        $query = "UPDATE usuario set usuario = '$usuario', contrasena = '$contrasena', tipoUsuario = '$tipoUsuario' WHERE idusuario = $codigo";
        mysqli_query($con, $query);

        header("Location: listarUsuarios.php");

    
    }   
?>
