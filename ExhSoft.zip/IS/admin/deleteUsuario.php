<?php
include("conection_database.php");
if(isset($_GET['codigo'])){
    $codigo= $_GET['codigo'];
    $query= "DELETE FROM usuario WHERE idusuario = $codigo";
    $result = mysqli_query($con, $query);
    if (!result){
        die("Query Failed");
    }

    $_SESSION['mensaje'] = '¡Usuario removido de manera exitosa';
    $_SESSION['tipoMensaje'] = 'succes';
    header("Location: listarUsuarios.php");
}


?>