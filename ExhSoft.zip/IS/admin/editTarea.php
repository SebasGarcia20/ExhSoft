<?php
    include("conection_database.php");

    if(isset($_POST['update'])){
        $codigo = $_GET['codigo'];
        $nombreTarea = $_POST['nombreTarea'];
        $demandante = $_POST['demandante'];
        $descripcion = $_POST['descripcion'];

        $query = "UPDATE tareas set nombreTarea = '$nombreTarea', iddemandante = '$demandante', descripcion = '$descripcion' WHERE idtareas = $codigo";
        echo $query;
        mysqli_query($con, $query);

        header("Location: listarTareas.php");

    
    }   
?>
