<?php include 'conection_database.php'; ?>
<?php include_once 'headerOfertante.php' ?>

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">
  <!-- Main Content -->
  <div id="content">
    <!-- Topbar -->
    <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
      <!-- Sidebar Toggle (Topbar) -->
      <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
        <i class="fa fa-bars text-dark"></i>
      </button>

      <!-- Topbar Buscador -->
      <form class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
        <div class="input-group">
          <input type="text" class="form-control bg-light border-0 small" placeholder="Buscar por..." aria-label="Search" aria-describedby="basic-addon2">
          <div class="input-group-append">
            <button class="btn btn-dark" type="button">
              <i class="fas fa-search fa-sm"></i>
            </button>
          </div>
        </div>
      </form>

      <!-- Topbar Navbar -->
      <ul class="navbar-nav ml-auto">

        <!-- Nav Item - Buscador Dropdown (Visible solo en contexto movil) -->
        <li class="nav-item dropdown no-arrow d-sm-none">
          <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-search fa-fw"></i>
          </a>
          <!-- Dropdown - Mensajes -->
          <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in" aria-labelledby="searchDropdown">
            <form class="form-inline mr-auto w-100 navbar-search">
              <div class="input-group">
                <input type="text" class="form-control bg-light border-0 small" placeholder="Buscar por..." aria-label="Search" aria-describedby="basic-addon2">
                <div class="input-group-append">
                  <button class="btn btn-primary" type="button">
                    <i class="fas fa-search fa-sm"></i>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </li>

        <div class="topbar-divider d-none d-sm-block d-lg-none"></div>

        <!-- Nav Item - Informacion de usuario -->
        <li class="nav-item dropdown no-arrow">
          <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['usuario'];?></span>
            <img class="img-profile rounded-circle" src="https://freepngimg.com/thumb/icon/1000561-red-hair-man-emoji-free-icon-thumb.png">
          </a>
          <!-- Dropdown - Informacion de usuario -->
          <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
            <a class="dropdown-item" href="#">
              <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
              Perfil
            </a>
            <a class="dropdown-item" href="#">
              <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
              Configuración
            </a>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
              <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
              Salir
            </a>
          </div>
        </li>

      </ul>

    </nav>
    <!-- Fin Topbar -->

    <!-- Inicio del contenido de la pagina -->
    <div class="container-fluid">
      <!-- Pagina heading -->
      <h1 class="h3 mb-4 text-gray-800">Gestionar Tareas Seleccionadas</h1>

      <div class="row">
        <!-- Listado de usuarios -->
        <div class="col-12">
          <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
              <h5 class="m-0 font-weight-bold text-dark">Tareas Seleccionadas</h5>
              <div class="dropdown no-arrow show">
                <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                  <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-400"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in" aria-labelledby="dropdownMenuLink" x-placement="top-end" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(-156px, -155px, 0px);">
                  <div class="dropdown-header">Opciones:</div>
                  <a class="dropdown-item" href="listarUsuarios.php">Ver todos los usuarios</a>
                  <a class="dropdown-item" href="crearUsuario.php">Añadir nuevo Usuario</a>
                  <a class="dropdown-item" href="modificarUsuario.php">Modificar un Usuariao</a>
                </div>
              </div>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTableUsuarios" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Código</th>
                      <th>ID Ofertante</th>
                      <th>Nombre Ofertante</th>
                      <th>ID Tarea</th>
                      <th>Nombre Tarea</th>
                      <th>Estado</th>
                      <th>Acciones</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Código</th>
                      <th>ID Ofertante</th>
                      <th>Nombre Ofertante</th>
                      <th>ID Tarea</th>
                      <th>Nombre Tarea</th>
                      <th>Estado</th>
                      <th>Acciones</th>
                    </tr>
                  </tfoot>
                  <tbody>
                  <?php
                      $sql="SELECT d.nomOfer, o.idofertante, o.idofertaTarea, o.estado, o.idtareas, t.nombreTarea FROM ofertante_tarea o inner join ofertante d on o.idofertante = d.idofertante inner join tareas t on o.idtareas = t.idtareas";
                      $result = mysqli_query($con, $sql);
                
                      while($fila = mysqli_fetch_array($result)){ ?>
                        <tr>
                            <td><?php echo $fila['idofertaTarea'] ?></td>
                            <td><?php echo $fila['idofertante'] ?></td>
                            <td><?php echo $fila['nomOfer'] ?></td>
                            <td><?php echo $fila['idtareas'] ?></td>
                            <td><?php echo $fila['nombreTarea'] ?></td>
                            <td><?php echo $fila['estado'] ?></td>
                            <td> 
                            <a href ="modificarOfertaTarea.php?codigo=<?php echo $fila['idofertaTarea']?>" class="btn btn-dark"> 
                                  <i class="fas fa-user-edit"></i> </a>
                            <a href ="deleteOfertaTarea.php?codigo=<?php echo $fila['idofertaTarea']?>" class="btn btn-danger"> 
                                   <i class="fas fa-user-times"></i> </a>
                             </td>

                        </tr>
                      <?php } ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- /.container-fluid -->
    </div>
    <!-- Fin Contenido principal -->


    <?php include_once '../codigoOldTownRoad/includes/templates/footerAdmin.php' ?>