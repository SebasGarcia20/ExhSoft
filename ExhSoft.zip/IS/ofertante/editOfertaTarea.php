<?php
    include("conection_database.php");

    if(isset($_POST['update'])){
        $codigo = $_GET['codigo'];
        $Tarea = $_POST['tarea'];
        $ofertante = $_POST['ofertante'];
        $estado = $_POST['estado'];

        $query = "UPDATE ofertante_tarea set idofertante = '$ofertante', idtareas = '$Tarea', estado = '$estado' WHERE idofertaTarea = $codigo";
        echo $query;
        mysqli_query($con, $query);

        header("Location: listarofertaTarea.php");

    
    }   
?>
